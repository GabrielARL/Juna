Juna red1 sweep transfer set
============================

Purpose
-------
This directory contains the Linux-only artifacts that the Windows bundle job
reported missing. The files are copied byte-for-byte from their source paths.

Not included
------------
red_1.mat is intentionally excluded because the Windows audit already found a
copy with SHA-256:
09556b49e453a351f72b5c71435aab0048f68a80ab3b926ca4353dab47e89c45

Windows handoff
---------------
1. Extract the ZIP into one directory, for example:
   C:\Users\Admin\Documents\Juna-windows-transfer-red1-2447abf
2. From PowerShell in that directory, verify:
   Get-Content .\SHA256SUMS | ForEach-Object {
       $parts = $_ -split '  ', 2
       $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $parts[1]).Hash.ToLowerInvariant()
       [pscustomobject]@{ File=$parts[1]; Expected=$parts[0]; Actual=$actual; Match=($actual -eq $parts[0]) }
   }
3. Give the Windows Codex agent the full extracted directory path.

Safety
------
These are historical source artifacts and inputs. Verify hashes before editing
or creating current-compatible runtime copies. Retired identifiers may remain
inside immutable historical inputs, but must not be carried into active current
runner code or current outputs.
