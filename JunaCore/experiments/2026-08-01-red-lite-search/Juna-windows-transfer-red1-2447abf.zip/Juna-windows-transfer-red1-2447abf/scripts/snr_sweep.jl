#!/usr/bin/env julia
#
# BER versus added-noise SNR over red1-4 x hydrophones 1-3, five receivers.
#
# CL-28: twelve curves, one per capture-lane path, each held at that path's own
# best-BER geometry from the 20 dB search. No aggregate curve, so no mixing of
# operating points.
# CL-29/CL-30: noise is the uwa-channels mixing model from red_noise.mat --
# alpha = 1.7, impulsive, correlated across the three hydrophones -- injected
# in place of the harness's AWGN. This is a different channel-application path
# from the 20 dB confirmation, and the two must not be plotted together.
#
# SNR follows Mahmood & Chitre, JOE 42(3) 2017 eq. (35): signal power over the
# alpha-stable pseudo-power 2*delta^2. Second-order moments do not exist at
# alpha < 2, so a variance-based SNR would be meaningless.
#
# Usage:
#   julia --project=. -t auto snr_sweep.jl smoke
#   julia --project=. -t auto snr_sweep.jl

module SnrSweep

include(joinpath(@__DIR__, "benchmark_port.jl"))
include(joinpath(@__DIR__, "uwa_noise.jl"))
using .BenchmarkPort
using .UwaNoise
using Random
const B = BenchmarkPort

const SNR_DB = 0:2:30
const FRAMES = 60
const SEED = 4                     # the search's reserved report seed
const FRAME_DURATION_S = 1.0
const FRAME_CRC_BITS = 16
const MODEM_FS = 9_600.0
const CHANNEL_IDS = (:red1, :red2, :red3, :red4)
const LANES = (1, 2, 3)
const CHANNEL_FILES = (red1="red_1.mat", red2="red_2.mat",
                       red3="red_3.mat", red4="red_4.mat")
const SEARCH = "/home/gabiel/Documents/GitHub/Juna/JunaCore/experiments/2026-08-01-red-lite-search"
const NOISE_MAT = joinpath(SEARCH, "data", "red_noise.mat")
const CZ_RESULTS = "/home/gabiel/Documents/GitHub/Juna-worktrees/profiled-cz-restore/JunaCore/experiments/2026-08-01-red-lite-search"

const ALGORITHMS = (
    (id=:ofdm_fec, name="OFDM + FEC", profile=:ofdm_fec),
    (id=:pfft, name="Partial-FFT + FEC", profile=:pfft),
    (id=:lite, name="JUNA-Lite", profile=:lite),
    (id=:profiled_cz, name="JUNA (C,z) frame gradient", profile=:profiled_cz),
    (id=:cwz_joint, name="Conditioned joint (C,W,z)", profile=:profiled_cz,
     cz_em_enabled=true, cz_independent_w=false, cz_bp_feedback=0.5,
     cz_vp_gradient=true, cz_conditioned_joint=true),
)

const CONFIG_KEYS = ("nfft", "cp", "code_rate", "outer_spacing",
                     "inner_spacing", "check_degree", "horizon")

"""Best-BER geometry per path, pooled over arms and both confirmation seeds.

CL-28 selects on BER, where the search itself ranked on effective rate, so
these are not the Results page's winners.
"""
function best_geometries()
    sources = [joinpath(SEARCH, "results",
                        "red_config_finalists_20db_seeds6to7.csv"),
               joinpath(SEARCH, "results_pfft",
                        "red_config_finalists_20db_seeds6to7.csv"),
               joinpath(CZ_RESULTS, "results_cz",
                        "red_profiled_cz_confirm_20db_seeds6to7.csv")]
    errors = Dict{Tuple,Int}()
    bits = Dict{Tuple,Int}()
    for source in sources
        isfile(source) || continue
        lines = readlines(source)
        header = split(lines[1], ',')
        index = Dict(name => i for (i, name) in pairs(header))
        for line in lines[2:end]
            isempty(strip(line)) && continue
            cells = split(line, ',')
            cells[index["algorithm_id"]] == "adaptive_lite" && continue
            key = (Symbol(cells[index["channel"]]),
                   parse(Int, cells[index["lane"]]),
                   Tuple(cells[index[k]] for k in CONFIG_KEYS))
            errors[key] = get(errors, key, 0) +
                parse(Int, cells[index["bit_errors"]])
            bits[key] = get(bits, key, 0) +
                parse(Int, cells[index["payload_bits"]])
        end
    end
    best = Dict{Tuple{Symbol,Int},Any}()
    for (key, bit_count) in bits
        bit_count == 0 && continue
        ber = errors[key] / bit_count
        path = (key[1], key[2])
        if !haskey(best, path) || ber < best[path].ber
            cells = key[3]
            best[path] = (ber=ber,
                          nfft=parse(Int, cells[1]), cp=parse(Int, cells[2]),
                          code_rate=parse(Float64, cells[3]),
                          outer_spacing=parse(Int, cells[4]),
                          inner_spacing=parse(Int, cells[5]),
                          check_degree=parse(Int, cells[6]),
                          horizon=parse(Int, cells[7]))
        end
    end
    best
end

"""Install the mixing-model noise for one hydrophone, then restore."""
function with_uwa_noise(body, model, lane::Integer, fs::Real;
                        gain=UwaNoise._chain_scale_gain(model, fs))
    task_local_storage(B.NOISE_OVERRIDE_KEY,
        (n, noise_power, rng) ->
            sqrt(noise_power) .* UwaNoise.baseband_noise(rng, model, lane, n,
                                                         fs; scale_gain=gain)) do
        body()
    end
end

function _evaluate(capture, channel_id, lane, config, snr_db; frames=FRAMES)
    rows = B.benchmark_frame_capture(
        capture;
        channel_id=String(channel_id), frames=Int(frames),
        frame_blocks=config.horizon == 0 ? nothing : Int(config.horizon),
        frame_duration_s=FRAME_DURATION_S, frame_crc_bits=FRAME_CRC_BITS,
        algorithms=ALGORITHMS, snr_db=Float64(snr_db), seed=SEED,
        modem_fs=MODEM_FS, modem_profile=:passband_replay, sync_profile=:lfm,
        nfft=config.nfft, cp=config.cp, code_rate=config.code_rate,
        check_degree=config.check_degree, ldpc_method=:auto,
        ldpc_seed=51_001, ldpc_no4cycle=true,
        outer_pilot_ratio=1 / config.outer_spacing,
        inner_pilot_ratio=1 / config.inner_spacing)
    [(channel=String(channel_id), lane=lane, snr_db=Float64(snr_db),
      algorithm_id=String(ALGORITHMS[i].id), seed=SEED, frames=Int(frames),
      nfft=config.nfft, cp=config.cp, code_rate=config.code_rate,
      outer_spacing=config.outer_spacing, inner_spacing=config.inner_spacing,
      check_degree=config.check_degree, horizon=config.horizon,
      payload_bits_per_frame=Int(row.payload_bits_per_frame),
      successful_frames=Int(row.successful_frames), psr=Float64(row.psr),
      payload_bits=Int(row.payload_bits), bit_errors=Int(row.bit_errors),
      ber=Float64(row.ber), decode_failures=Int(row.decode_failures),
      decode_seconds=Float64(row.mean_decode_seconds_per_frame),
      effective_rate_bps=Float64(row.effective_rate_bps))
     for (i, row) in pairs(rows)]
end

function _write_csv(destination, rows)
    isempty(rows) && return destination
    names = keys(first(rows))
    open(destination, "w") do io
        println(io, join(names, ','))
        for row in rows
            println(io, join((getproperty(row, n) for n in names), ','))
        end
    end
    destination
end

function smoke(data_dir=joinpath(@__DIR__, "data"))
    model = UwaNoise.load_model(NOISE_MAT)
    geometries = best_geometries()
    config = geometries[(:red1, 1)]
    println("red1 lane 1 best-BER geometry: N=", config.nfft, " CP=", config.cp,
            " rate=", config.code_rate, " pilots=", config.outer_spacing, "/",
            config.inner_spacing, " dc=", config.check_degree,
            " K=", config.horizon, "  (20 dB BER ", round(config.ber, sigdigits=3), ")")
    capture = B.load_capture(joinpath(data_dir, CHANNEL_FILES.red1); receiver=1)
    with_uwa_noise(model, 1, MODEM_FS) do
        for snr in (0.0, 20.0)
            for row in _evaluate(capture, :red1, 1, config, snr; frames=3)
                println("  SNR ", rpad(snr, 5), " ", rpad(row.algorithm_id, 12),
                        " psr=", rpad(round(row.psr, digits=3), 6),
                        " ber=", round(row.ber, sigdigits=4))
            end
        end
    end
end

"""One capture-lane path, the SNR ladder split across threads.

With twelve paths the natural unit of parallelism was the path. For a single
path the ladder is the only thing left to split, so the sixteen SNR points are
dealt out one group per thread. Each group loads its own capture rather than
sharing one: the harness was not written for concurrent readers, and a silent
data race here would look like scatter in the curve.
"""
function run(channel::Symbol=:red1, lane::Integer=1;
             data_dir=joinpath(@__DIR__, "data"), out_dir=@__DIR__)
    model = UwaNoise.load_model(NOISE_MAT)
    config = best_geometries()[(channel, lane)]
    println(channel, " lane ", lane, " best-BER geometry: N=", config.nfft,
            " CP=", config.cp, " rate=", config.code_rate, " pilots=",
            config.outer_spacing, "/", config.inner_spacing, " dc=",
            config.check_degree, " K=", config.horizon,
            "  (20 dB BER ", round(config.ber, sigdigits=3), ")")
    flush(stdout)

    snrs = collect(SNR_DB)
    groups = max(1, min(Threads.nthreads(), length(snrs)))
    chunks = [snrs[i:groups:end] for i in 1:groups]
    rows_by_chunk = Vector{Vector{NamedTuple}}(undef, groups)
    gain = UwaNoise._chain_scale_gain(model, MODEM_FS)
    file = joinpath(data_dir, getproperty(CHANNEL_FILES, channel))
    # Loaded once and shared. `ReplayCapture` is an immutable struct and
    # nothing in the replay path assigns into it, so concurrent readers are
    # safe. One copy per thread cost four 191 MB captures and pushed the
    # machine into memory pressure, which stalled the run.
    capture = B.load_capture(file; receiver=lane)
    println("capture loaded; sweeping ", length(snrs), " SNR points on ",
            groups, " threads")
    flush(stdout)

    Threads.@threads for index in 1:groups
        rows_by_chunk[index] = NamedTuple[]
        try
            for snr in chunks[index]
                rows = with_uwa_noise(model, lane, MODEM_FS; gain=gain) do
                    _evaluate(capture, channel, lane, config, snr)
                end
                append!(rows_by_chunk[index], rows)
                println("  ", channel, " lane ", lane, " SNR ", snr, " done")
                flush(stdout)
            end
        catch exception
            exception isa InterruptException && rethrow()
            @warn "chunk failed" index exception
        end
    end

    rows = sort(reduce(vcat, rows_by_chunk); by = r -> (r.snr_db, r.algorithm_id))
    destination = _write_csv(joinpath(out_dir, "red_snr_sweep_uwa_noise.csv"), rows)
    println("DONE ", channel, " lane ", lane)
    println("wrote ", destination, " (", length(rows), " rows)")
    rows
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    if length(ARGS) >= 1 && ARGS[1] == "smoke"
        SnrSweep.smoke()
    else
        channel = length(ARGS) >= 1 ? Symbol(ARGS[1]) : :red1
        lane = length(ARGS) >= 2 ? parse(Int, ARGS[2]) : 1
        SnrSweep.run(channel, lane)
    end
end
